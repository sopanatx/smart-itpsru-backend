export class tokenModel {
  accessToken: string;
}
