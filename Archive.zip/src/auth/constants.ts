export const JwtConstants = {
  secret: 'The Typescript World',
};
